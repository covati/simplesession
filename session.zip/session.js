const format = require("./format");
const cache = require("./cache");

exports.handler = async (event) => {
    traverse(event);

    const client = cache.client_setup(process.env);
    
    const session_data = await get_session(event, client);
    
    console.log("Session data is : "+ session_data)
    return format.return(200,"Got back session data!", session_data);
};

/**
 * @param {event} event The event object
 * @param {redis_client} client a connected redis client, call from within on-ready
 */
function get_session(event, client) {
    return new Promise(function (resolve, reject) {
        client.on('error', function (err) {
            console.log('>>>>> Failed to connect to session cache ' + err);
            reject(format.return(500,"Failed to get session data,"+ err,err));
        }).on('ready', function () {
            // test a failure
            // reject(format.return(500,"Failed to find a header in this request"));
            
            if (! ("method" in event)){
                console.log("No Method passed in");
                reject(format.return(500,"Failed to find a header in this request","Failed to find a header in this request"));
            } else if (event.method == 'GET') {
                session_id = event.params.querystring.session_id;
                const my_get = cache.get_value(client, session_id);
                my_get.then(function(reply){
                    resolve(reply);
                });
            } else if (event.method == 'POST'){
                session_id   = event.body.session_id;
                session_data = event.body.session_data;

                const my_set = cache.set_value(client, session_id, session_data);
                my_set.then(function(reply){
                    resolve(reply);
                });
            } else {
                reject(format.return(500,"Bad method supplied: "+ event.headers["method"],"Bad method supplied: "+ event.headers["method"]))
            }
        });
    });
}

function traverse(my_obj, prefix){
    console.log("Traversing an obj, keys: "+ Object.keys(my_obj).length)
    if(! prefix){ prefix = ">";}
    Object.keys(my_obj).forEach(function(key) {
        var val = my_obj[key];
        if (typeof val == "object"){
            console.log(prefix+"<"+ key +">")
            traverse(val, prefix+key+" > ");
            console.log(prefix+"</"+ key +">")
        } else {
            console.log(prefix +"'"+ key +"': "+ val);
        }
    });
}
