module.exports.return = function (code, message, body) {
    console.log(message);
    
    var success = {
        statusCode: code,
        body: body,
    };
    return success;
}